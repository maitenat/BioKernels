#' PFAM kernel matrix
#'
#' Given a FASTA file, these sequences are searched against a protein profile/domain database using hmmscan function from HMMER. The E-values of this search are stored in a matrix and logged (natural logarithm). For obtaining the PFAM kernel matrix, a kernel function needs to be then applied to the output matrix of this function.

#' @param FASTAFile the name of the FASTA file that includes the proteins to build the kernel matrix with.  If it does not contain an absolute path, the file name is relative to the current working directory, \code{\link[base]{getwd}}.
#' @param pfamDB (hmmscan parameter). The target database of profiles. If it does not contain an absolute path, the file name is relative to the current working directory, \code{\link[base]{getwd}}. See Details section for further details. 
#' @param incdomE (hmmscan parameter). Optional parameter giving a conditional E-value that works as per-domain inclusion threshold, in targets that have already satisfied the overall per-target inclusion threshold. Default value is 0.01.
#' @param domE (hmmscan parameter). In the per-domain output, for target profiles that have  already satisfied the per-profile reporting threshold, report individual domains with a conditional E-value smaller than the value given by this parameter. Default value is 10. A conditional  E-value  means the expected  number of additional false positive domains in the smaller search space of those comparisons that already satisfied the per-profile reporting threshold (and thus must have at least one  homologous domain already).
#' @param incE (hmmscan parameter). Optional parameter giving the per-target inclusion E-value threshold. Default value is 0.01. 
#' @return A protein x domain matrix that includes logged E-values of each protein containing each domain. 
#' @export
#' @details Given a FASTA file, this function does a domain search in a pfam database for each protein, by using hmmscan function from HMMER 3.0. The E-score of the best match between a protein and a domain is then taken and stored in a matrix. To the "no-hits", i.e. protein-domain pairs that do not exceed the E-score threshold, an E-value that is the maximum of the aligned pairs plus 10 units is assigned, as it can be assumed that these missing alignments are worse than all the provided ones.
#' 
#' For PFAMkm function to work, HMMER 3.0 (and no other older version) needs to be installed. HMMER is a software package for sequence analysis and works by comparing sequences to profile-hidden Markov models. Although several different HMM databases can be used with HMMER, for this kernel, PFAM database is required. The user can choose whether to only use the manually curated portion of the database (Pfam-A) or to also add the automatically generated part (Pfam-B). This database needs to be compressed and indexed previous to create the kernel, and hence pfamdb variable should point to this last database. The user manual can be seen in the following link: \url{http://hmmer.janelia.org/}.
#' 
#' The FASTA file is read by the \code{\link[seqinr]{read.fasta}} function. Details are described in the documentation of the function. 
#' @usage PFAMkm (FASTAFile, pfamDB, incdomE = 0.01, domE = 10, 
#' incE = 0.01)
#' @references HMMER 3.0 (March 2010); http://hmmer.org/
#' Copyright (C) 2010 Howard Hughes Medical Institute.
#' Freely distributed under the GNU General Public License (GPLv3)
#' @seealso \code{\link{BLASTkm}} for BLAST kernel matrices, \code{\link{SWkm}} for SW kernel matrices, \code{\link{FFTkm}} for hydropathy FFT kernel matrices, \code{\link[kernlab]{vanilladot}} for linear kernel function, \code{\link[kernlab]{rbfdot}} for Gaussian RBF kernel function.
#' @examples 
#' # Construction of a small PFAM kernel matrix given a sample globin FASTA file:
#' 
#' # Compress and index the database flatfile
#' dbFilename <- system.file("extdata/globins", package = "BioKernels")
#' system(paste("hmmpress ", dbFilename, sep = ""))
#' 
#' # Create the PFAM matrix
#' seqFilename <- system.file("extdata/globins.FASTA", package = "BioKernels")
#' PFAMMat <- PFAMkm(seqFilename, pfamDB = dbFilename)
#' 
#' # Create a PFAM kernel matrix applying a linear kernel to this matrix
#' library(kernlab)
#' linearKernel <- vanilladot()
#' PFAMLinearKernelMat <- kernelMatrix(linearKernel, scale(PFAMMat))
#' 
#' # Create a PFAM kernel matrix applying a gaussian RBF kernel to this matrix
#' radialKernel <- rbfdot(sigma = 0.1)
#' PFAMRBFKernelMat <- kernelMatrix(radialKernel, scale(PFAMMat))
#' 
PFAMkm <- function(FASTAFile, pfamDB, incdomE = 0.01, domE = 10, incE = 0.01) {
  # We run hmmscan (from HMMER 3) against PFAM local database.
  # In and outfiles and name of the pfam local database (do not include binary file extension), including the path
  inFile <- FASTAFile
  outFile <- paste(strsplit(basename(FASTAFile), ".FASTA")[[1]], ".pfamout", sep = "")
  # We create comands function
  cmdCreate <- function(inFile, outFile, pfamDB, incdomE, domE, incE){
    paste("hmmscan --domtblout ",outFile, " --incdomE ",incdomE, " --domE " ,domE, " --incE ",incE, " ",pfamDB, " ",inFile, sep = "")
  }
  
  # Create actual comands
  cmds <- mapply(FUN = cmdCreate, inFile = inFile, pfamDB = pfamDB, outFile = outFile, incdomE, domE, incE)
  # We run the comands
  sapply(cmds, system)
  
  # We modify a little bit the output file
  splitCom <- paste("awk -F ' ' '{print $1, $4, $13}' ",outFile, " > reduced", outFile, sep = "")
  system(splitCom)
  
  # We read the file we have just created/modified
  allSeqPFAMOut <- read.table(paste("reduced", outFile, sep = ""), sep = " ")
  factorMask <- sapply(allSeqPFAMOut, is.factor)
  allSeqPFAMOut[factorMask] <- lapply(allSeqPFAMOut[factorMask], as.character)
  
  # We remove the created temporal files, which are no more necessary
  commandRemove <- paste("rm *", outFile, sep = "")
  system(commandRemove)
  
  # We create the protein vs domain matrix
  # We upload the label data and create empty matrix
  
  temp <- read.fasta(FASTAFile)
  protNames <- paste(strsplit(FASTAFile, ".FASTA")[[1]], ".names", sep = "")
  EScoreKernelMatrix <- matrix(NA, nrow = length(temp), ncol = length(unique(allSeqPFAMOut[,1])))
  rownames(EScoreKernelMatrix) <- names(temp)
  colnames(EScoreKernelMatrix) <- unique(allSeqPFAMOut[,1])
  # Remove those lines in which we have the same first and second element (keep the first one)
  allSeqPFAMOutUnique <- allSeqPFAMOut[!duplicated(allSeqPFAMOut[,1:2]),]
  # We fill the E-score matrix
  for (i in 1:nrow(allSeqPFAMOutUnique)) {
    temp <- allSeqPFAMOutUnique[i,]
    EScoreKernelMatrix[as.character(temp[2]), as.character(temp[1])] <- as.numeric(temp[3])
  }
  # We fill those pairs with an NA with the maximum E-value in the matrix + 10
  EScoreKernelMatrix[is.na(EScoreKernelMatrix)] <- max(allSeqPFAMOutUnique[,3]) + 10
  class(EScoreKernelMatrix) <- "numeric"
  loggedEScoreKernelMatrix <- log(EScoreKernelMatrix)
  loggedEScoreKernelMatrix[loggedEScoreKernelMatrix == -Inf] <- -999
  return(loggedEScoreKernelMatrix)
}
