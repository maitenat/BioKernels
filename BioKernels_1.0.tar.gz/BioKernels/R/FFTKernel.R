#' Hydropathy FFT kernel matrix
#'
#'Given a FASTA file, the hydropathy vectors for each protein are calculated based on Kyte-Doolittle indices for each aminoacid, and they are subsequently low-pass filtered in order to reduce noise. The frequency contents of the hydropathy profiles are then computed through the fast Fourier transform (FFT) algorithm. For obtaining the hydropathy FFT kernel matrix, a kernel function needs to be then applied to the output matrix of this function.
#'
#' @param FASTAFile the name of the FASTA file that includes the proteins to build the kernel matrix with.  If it does not contain an absolute path, the file name is relative to the current working directory, \code{\link[base]{getwd}}.
#' @return A matrix containing in each row the absolute value of the result of applying FFT algorithm to the hydropathy profiles of each protein. The number of columns will be equal to the length of the longest protein in the matrix.
#' @export
#' @details 
#' This kernel incorporates information about hydropathy patterns. 
#' Given a FASTA file, the hydropathy vectors for each protein are calculated based on Kyte-Doolittle indices for each aminoacid; selenocysteine, pyrrolysine and formylmethionine are skipped as there is no index for these aminoacids. These vectors are subsequently low-pass filtered in order to reduce noise with a filter with the following impulse response: f = (0.25, 0.5, 0.25). After that vectors are zero-padded, i.e. zeros are added at the end of the vectors so that they all have the same length, that is the length of the longest profile. Subsequently, the frequency contents of these profiles are computed through the FFT algorithm and the final matrix is constructed by storing in each row the absolute value of these transformed vectors. For obtaining the hydropathy FFT kernel matrix, a kernel function needs to be then applied to the output matrix of this function.
#' 
#' The FASTA file is read by the \code{\link[seqinr]{read.fasta}} function. Details are described in the documentation of the function. 
#' 
#' @usage FFTkm(FASTAFile)
#' @seealso \code{\link{BLASTkm}} for BLAST kernel matrices, \code{\link{PFAMkm}} for PFAM kernel matrices, \code{\link{SWkm}} for SW kernel matrices, \code{\link[kernlab]{vanilladot}} for linear kernel function, \code{\link[kernlab]{rbfdot}} for Gaussian RBF kernel function.
#' @references Kyte, J; Doolittle, R. F. (1982). "A simple method for displaying the hydropathic character of a protein". Journal of Molecular Biology 157 (1): 105–32. 
#' @examples 
#' # Construction of a small hydropathy FFT kernel matrix given a sample small FASTA file:
#'
#'# Create the hydropathy FFT matrix
#' seqFilename <- system.file("extdata/sample.FASTA", package = "BioKernels")
#' FFTMat <- FFTkm(seqFilename)
#' 
#' # Create a hydropathy FFT kernel matrix applying a linear kernel to this matrix
#' library(kernlab)
#' linearKernel <- vanilladot()
#' FFTLinearKernelMat <- kernelMatrix(linearKernel, scale(FFTMat))
#' 
#' # Create a hydropathy FFT kernel matrix applying a gaussian RBF kernel to this matrix
#' radialKernel <- rbfdot(sigma = 0.1)
#' FFTRBFKernelMat <- kernelMatrix(radialKernel, scale(FFTMat))
#'  
FFTkm <- function(FASTAFile) {
  data <- read.fasta(FASTAFile)
  
  # Kyte-Doolittle index for the 20 standard aminoacids
  # The Kyte & Doolittle Hydropathy indeces are needed. First look at the entries with Kyte as author
  data(aaindex)
  ind <- which(sapply(aaindex, function(x) length(grep("Kyte", x$A)) != 0))
  aaKDIndex <- aaindex[[ind]]$I
  
  # Convert three letter aa symbols into one letter code:
  # Use a text file with the symbol-one letter code conversion:
  aaFilename <- system.file("data/aaConvTable.txt", package = "BioKernels")
  aaSymbol3LetterTable <- read.table(aaFilename, sep = " ")
  names(aaKDIndex) <- aaSymbol3LetterTable[match(aaSymbol3LetterTable[,1], names(aaKDIndex)),2]
  
  # Create for each protein the vector containing the hydropathies of the aminoacids along the protein
  getProteinHydropProfile <- function(protein, aaKDIndex){
    seq <- toupper(getSequence(protein))
    return(aaKDIndex[seq][!is.na(aaKDIndex[seq])])
  }
  allDataHydropProfile <- sapply(data, getProteinHydropProfile, aaKDIndex = aaKDIndex) 
  
  # Pre-filtering of the hydropathy profiles to reduce noise
  filterIR <- 1/4 * c(1, 2, 1)
  lowPassFilter <- function(h, IR) {
    return(convolve(IR, rev(h), type = "o"))
  }
  filtAllDataHydropProfile <- lapply(allDataHydropProfile, lowPassFilter, IR = filterIR)
  
  # Compute the frequency contents through Fourier transform (FFT)
  # First zero-padd all vectors to a common length (the maximum of all)
  profileLengths <- lapply(filtAllDataHydropProfile, length)
  maxProfileLength <- max(unlist(profileLengths))
  zeroPad <- function(vector, maxLength) {
    return (c(vector, rep(0, maxLength - length(vector))))
  }
  readyAllDataHydropProfile <- lapply(filtAllDataHydropProfile, zeroPad, maxLength = maxProfileLength)
  
  # Compute the FFT
  aaFreqContents <- lapply(readyAllDataHydropProfile, fft) 
  rm(readyAllDataHydropProfile)
  rm(filtAllDataHydropProfile)
  rm(allDataHydropProfile)
  
  aaFreqContentMatrix <- matrix(as.integer(abs(unlist(aaFreqContents))), nrow = length(aaFreqContents), byrow = TRUE)
  rownames(aaFreqContentMatrix) <- names(aaFreqContents)
  return(aaFreqContentMatrix)
}