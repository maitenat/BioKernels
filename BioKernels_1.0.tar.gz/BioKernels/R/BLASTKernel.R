#' BLAST kernel matrix
#'
#' Given a FASTA file, it calculates all protein pairwise combination BLAST alignments using blastp program from blast+ suites, takes the E-values from these alignments and stores them in a square, symmetrical matrix. The kernel matrix is obtained by logging (applying a natural logarithm) this matrix. 
#' @param FASTAFile the name of the FASTA file that includes the proteins to build the kernel matrix with.  If it does not contain an absolute path, the file name is relative to the current working directory, \code{\link[base]{getwd}}.
#' @param gapopen (BLAST parameter). An optional numeric value giving the penalty taken away from the score when a gap is created in sequence. Note that increasing the gap openning penalty will decrease the number of gaps in the final alignment. Default value is 11. 
#' @param gapextend (BLAST parameter). An optional numeric value giving the penalty taken away from the score for each base or residue in the gap. Increasing the gap extension penalty favors short gaps in the final alignment, conversly decreasing the gap extension penalty favors long gaps in the final alignment. Default value is 1.
#' @param matrix (BLAST parameter). The substitution matrix used for scoring alignments when searching the database. This must be one of "BLOSUM80", "BLOSUM62", "BLOSUM50", "BLOSUM45", "PAM250", "BLOSUM90", "PAM30" or "PAM70". Default matrix is "BLOSUM62". 
#' @param evalue (BLAST parameter). An optional numeric value that limits the number of scores and alignments reported based on the expectation value. This is the maximum number of times the match is expected to occur by chance. Default value is 10.
#' @return A kernel matrix constructed with BLAST protein alignment data.
#' @seealso \code{\link{PFAMkm}} for PFAM kernel matrices, \code{\link{SWkm}} for SW kernel matrices, \code{\link{FFTkm}} for hydropathy FFT kernel matrices
#' @export
#' @details Given a FASTA file, it calculates all protein pairwise combination BLAST alignments using blastp program from blast+ suites, takes the best E-value from each of these alignments and stores them in a square, symmetrical matrix. The kernel is obtained by logging (applying a natural logarithm) this matrix. Notice that BLAST does not show alignment results for all pairs but for just the "best" ones. Here an E-value that is the maximum of the aligned pairs + 10 is assigned to those pairs, as it can be assumed that these missing alignments are worse than all the provided ones.
#' 
#' Aminoacids pyrrolysine and selenocysteine are treated as they were "unknown" (X).
#' 
#' The FASTA file is read by the \code{\link[seqinr]{read.fasta}} function. Details are described in the documentation of the function. 
#' 
#' For BLASTkm function to work, BLAST+ library (command line standalone blast+ programs) needs to be installed. See \url{http://www.ncbi.nlm.nih.gov/books/NBK279671/} for information about installation. 
#' @usage BLASTkm (FASTAFile, gapopen = 11, gapextend = 1, 
#' matrix = "BLOSUM62", evalue = 10)
#' @references Camacho C., Coulouris G., Avagyan V., Ma N., Papadopoulos J., Bealer K., & Madden T.L. (2008) "BLAST+: architecture and applications." BMC Bioinformatics 10:421.
#' @examples 
#' # Construction of a small BLAST kernel matrix given a sample small FASTA file:
#' 
#' filenameA <- system.file("extdata/sample.FASTA", package = "BioKernels")
#' BLASTKernelMatA <- BLASTkm(filenameA)
#' 
#' filenameB <- system.file("extdata/globins.FASTA", package = "BioKernels")
#' BLASTKernelMatB <- BLASTkm(filenameB)
#' 
BLASTkm <- function(FASTAFile, gapopen = 11, gapextend = 1, matrix = "BLOSUM62", evalue = 10) {
  data <- read.fasta(FASTAFile)
  EScoreKernelMatrix <- matrix(NA, nrow = length(data), ncol = length(data))
  rownames(EScoreKernelMatrix) <- names(data)
  colnames(EScoreKernelMatrix) <- names(data)
  inFile <- FASTAFile
  outFile <- paste(strsplit(basename(FASTAFile), ".FASTA")[[1]], ".blout", sep = "")
  
  # As we are using command line blastp program from blast+ suites, we simply create the commands for running BLAST and call them from inside R
  
  # We create comands function
  cmdCreate <- function(inFile, outFile, gapopen, gapextend, matrix, evalue){
    paste("blastp -query ",inFile, " -subject ",inFile, " -out ",outFile, " -outfmt 6 -gapopen ",gapopen, " -gapextend " ,gapextend, " -matrix ",matrix, " -evalue ",evalue, sep = "")
  }
  
  # Recall the flafs of blastp: -query for input query filename, -subject for filename with subject sequences to search, -out for output filename, -outfmt 6 shows alignment results in tabular form, -gapopen, -gapextend and -matrix determine the costs to open a gap, extend it and the scoring matrix name, respectively, -evalue is the expectation value (E-value) threshold for saving hits
  
  # Notice also that selenocysteine (U) is not specified in the BLAST scoring matrices. Blast masks it from the search by changing it to X.
  
  # Create actual comands
  cmds <- mapply(FUN = cmdCreate, inFile = inFile, outFile = outFile, gapopen = gapopen, gapextend = gapextend, matrix = matrix, evalue = evalue)
  
  # Run the comands
  sapply(cmds, system)
  
  # The file is too big to be readed into memory, so in the command line we just select the neccessary columns: 1, 2 and 11
  newOutfile <- paste("reduced", outFile, sep = "")
  commandSimplify <- paste("cut -f1,2,11 ", outFile, " > ", newOutfile, sep = "")
  system(commandSimplify)
  
  # Read the created file 
  allSeqBLASTOut <- as.matrix(read.table(newOutfile, sep = "\t"))
  
  # We first remove the created temporal files, which are no more necessary
  commandRemove <- paste("rm *", outFile, sep = "")
  system(commandRemove)
  
  # We remove duplicated lines, i.e. those refering to the same alignment but done in different order. We take the alignment with the lowest E-score
  # For the function to work properly, we have to give it the data.frame with first two columns being the names of the aligned proteins and the third one with the E-value
    removeDuplicatedAlignments <- function(dataMatrix){
    temp <- matrix(as.numeric(factor(dataMatrix[,1:2])), nrow = nrow(dataMatrix))
    mn <- pmin(temp[,1], temp[,2])
    mx <- pmax(temp[,1], temp[,2])
    int <- as.numeric(interaction(mn, mx))  
    return(dataMatrix[match(unique(int), int),])
  }
  allSeqBLASTOutUnique <- removeDuplicatedAlignments(allSeqBLASTOut)
  
  # Fill the E-score matrix with the data 
  for (i in 1:nrow(allSeqBLASTOutUnique)) { #bottleneck
    temp <- allSeqBLASTOutUnique[i,]
    EScoreKernelMatrix[temp[1], temp[2]] <- as.numeric(temp[3])
    EScoreKernelMatrix[temp[2], temp[1]] <- as.numeric(temp[3])
  }
  
  # As said, the give a synthetic E-value that is the maximum of the aligned ones + 10 units to the non-aligned pairs
  EScoreKernelMatrix[is.na(EScoreKernelMatrix)] <- max(allSeqBLASTOutUnique[,3])
  class(EScoreKernelMatrix) <- "numeric"
  
  # Final adjustments: apply logarithms and substitute -Inf values by -999
  loggedEScoreKernelMatrix <- log(EScoreKernelMatrix) 
  max(diag(EScoreKernelMatrix)) #1e-12
  max(EScoreKernelMatrix) # 190
  loggedEScoreKernelMatrix[loggedEScoreKernelMatrix == -Inf] <- -999
  return(loggedEScoreKernelMatrix)
}