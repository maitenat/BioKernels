#' Smith-Waterman kernel matrix
#'
#' Given a FASTA file, it calculates all protein pairwise combination Smith-Waterman alignments, takes the E-values from these alignments and stores them in a square, symmetrical matrix. The kernel matrix is obtained by logging (applying a natural logarithm) this matrix. 

#' @param FASTAFile the name of the FASTA file that includes the proteins to build the kernel matrix with.  If it does not contain an absolute path, the file name is relative to the current working directory, \code{\link[base]{getwd}}.
#' @param gapopen (Smith-Waterman parameter). An optional numeric value giving the penalty taken away from the score when a gap is created in sequence. Note that increasing the gap openning penalty will decrease the number of gaps in the final alignment. Default value is 11. 
#' @param gapextend (Smith-Waterman parameter). An optional numeric value giving the penalty taken away from the score for each base or residue in the gap. Increasing the gap extension penalty favors short gaps in the final alignment, conversly decreasing the gap extension penalty favors long gaps in the final alignment. Default value is 1.
#' @param matrix (Smith-Waterman parameter). The substitution matrix used for scoring alignments when searching the database. This must be one of "BLOSUM45", "BLOSUM50", "BLOSUM62", "BLOSUM80", "BLOSUM100", "PAM30", "PAM40", "PAM70", "PAM120" or "PAM250". Default matrix is "BLOSUM62". 
#' @return A kernel matrix constructed with Smith-Waterman protein alignment data. 
#' @export
#' @details 
#' Given a FASTA file, it calculates all protein pairwise combination Smith-Waterman alignments using \code{\link[Biostrings]{pairwiseAlignment}} function, takes the E-value from each of these alignments and stores them in a square, symmetrical matrix. The kernel is obtained by logging (applying a natural logarithm) this matrix. E-values are calculated using Karlin-Altschul statistics.
#' 
#' Aminoacids pyrrolysine and selenocysteine are treated as they were "unknown" (X).
#' 
#' The FASTA file is read by the \code{\link[seqinr]{read.fasta}} function. Details are described in the documentation of the function. 
#' 
#' @usage SWkm(FASTAFile, gapopen = 11, gapextend = 1, matrix = "BLOSUM62")
#' @seealso \code{\link{BLASTkm}} for BLAST kernel matrices,  \code{\link{PFAMkm}} for PFAM kernel matrices, \code{\link{FFTkm}} for hydropathy FFT kernel matrices
#' @references Altschul, S.F. & Gish, W. (1996) "Local alignment statistics." Meth. Enzymol. 266:460-480.
#' @examples 
#' # Construction of a small Smith-Waterman kernel matrix given a sample small FASTA file:
#' 
#' filenameA <- system.file("extdata/sample.FASTA", package = "BioKernels")
#' SWKernelMatA <- SWkm(filenameA)
#' 
#' filenameB <- system.file("extdata/globins.FASTA", package = "BioKernels")
#' SWKernelMatB <- SWkm(filenameB)
#' 
SWkm <- function(FASTAFile, gapopen = 11, gapextend = 1, matrix = "BLOSUM62") {
  
  alignAndGetScore <- function(dataset, index.a, index.b, substMatrix, gapped, gapopen, gapextend){
    seq1 <- toupper(getSequence(dataset[[index.a]], as.string = TRUE)[[1]]) 
    seq2 <- toupper(getSequence(dataset[[index.b]], as.string = TRUE)[[1]]) 
    score <- pairwiseAlignment(seq1, seq2, substitutionMatrix = substMatrix, gapOpening = -gapopen, gapExtension = -gapextend, type = "local", scoreOnly = TRUE) 
    
    # Calculate the E-score  
    if (gapped) {
      lambda <- 0.267
      K <- 0.041
    } else {
      lambda <- 0.31721
      K <- 0.134187
    }
    m <- length(dataset[[index.a]])
    n <- length(dataset[[index.b]])
    EScore <- K*m*n*exp(-lambda*score)
    return (EScore)
  }
  # Create a modified substitution matrix that contains the penalties for U and O
  data(list = matrix)
  matrixData <- get(matrix)
  temp <- matrixData["X", "X"]
  tempVec <- matrixData["X",]
  matrixDataMod <- matrix(temp, nrow = nrow(matrixData)+2, ncol = ncol(matrixData)+2)
  matrixDataMod[1:nrow(matrixData), 1:ncol(matrixData)] <- matrixData
  matrixDataMod[(nrow(matrixData)+1):nrow(matrixDataMod), 1:ncol(matrixData)] <- rbind(tempVec, tempVec)
  matrixDataMod[1:ncol(matrixData), (nrow(matrixData)+1):nrow(matrixDataMod)] <- cbind(tempVec, tempVec)
  colnames(matrixDataMod) <- c(colnames(matrixData), "U", "O")
  rownames(matrixDataMod) <- c(colnames(matrixData), "U", "O")
  class(matrixDataMod) <- "numeric"
  
  # Evaluate whether the alignment is gapped or not
  gapped <- gapopen == 0 | gapextend == 0

  # Create the kernel matrix
  data <- read.fasta(FASTAFile)
  all_pairs<- combn(1:length(data), 2)
  PW_EScore_vector <- apply(all_pairs, 2, function(indices)  alignAndGetScore(data, indices[1], indices[2], matrixDataMod, gapped, gapopen = gapopen, gapextend = gapextend) )
  diag_pairs <- 1:length(data)
  Diag_EScore_vector <- sapply(diag_pairs,  function(indices) alignAndGetScore(data, indices, indices, matrixDataMod, gapped, gapopen = gapopen, gapextend = gapextend), simplify = "array")
  EScoreKernelMatrix <- matrix(0, nrow = length(data), ncol = length(data))
  rownames(EScoreKernelMatrix) <- names(data)
  colnames(EScoreKernelMatrix) <- names(data)
  EScoreKernelMatrix[upper.tri(EScoreKernelMatrix)] <- PW_EScore_vector
  EScoreKernelMatrix <- t(EScoreKernelMatrix)
  EScoreKernelMatrix[upper.tri(EScoreKernelMatrix)] <- PW_EScore_vector
  diag(EScoreKernelMatrix) <- Diag_EScore_vector
  loggedEScoreKernelMatrix <- log (EScoreKernelMatrix)
  loggedEScoreKernelMatrix[loggedEScoreKernelMatrix == -Inf] <- -999
  return(loggedEScoreKernelMatrix)
}

